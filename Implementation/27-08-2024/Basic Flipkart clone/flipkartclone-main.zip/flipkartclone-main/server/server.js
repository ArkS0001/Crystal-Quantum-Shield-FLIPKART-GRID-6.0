const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors'); // Import CORS

const app = express();
const port = 3001;

// Temporary in-memory storage for demonstration
const users = {};

app.use(cors()); // Use CORS middleware
app.use(bodyParser.json());

// API endpoint for login
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;

    if (!users[email]) {
        return res.status(400).json({ error: 'User not found!' });
    }

    if (users[email].password !== password) {
        return res.status(400).json({ error: 'Incorrect password!' });
    }

    res.status(200).json({ message: 'Login successful!' });
});

// API endpoint for signup
app.post('/api/signup', (req, res) => {
    const { name, email, password } = req.body;

    if (users[email]) {
        return res.status(400).json({ error: 'User already exists!' });
    }

    users[email] = { name, email, password };
    console.log(users[email]);
    res.status(200).json({ message: 'Signup successful!' });
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
