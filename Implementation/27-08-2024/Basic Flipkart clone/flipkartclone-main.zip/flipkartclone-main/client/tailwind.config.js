/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["C:\Users\ayush\Downloads\flipkartclone-main\index.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}

